create PROCEDURE          NINE_REPORT(YEAR VARCHAR2,SEASON VARCHAR2)

   AUTHID CURRENT_USER IS
   X NUMBER;
  V_SQL VARCHAR2(2000);
  
  CURSOR CURSOR_1 IS
    SELECT ADD_MONTHS(ADD_MONTHS(TO_DATE(YEAR,'yyyy'),A * 3),-ROWNUM-3)  BATCH  
    FROM (SELECT SEASON A FROM DUAL)  
    CONNECT BY ROWNUM <= 3  
    ORDER BY 1;   
  
  
 
    
    BEGIN
      DELETE FROM NINREPORT T WHERE T.YEAR = YEAR AND T.SEASON = SEASON;
      COMMIT;
      V_SQL := 'SELECT  house_name';
      X:=1;

      FOR V_BATCH IN CURSOR_1
      LOOP
      
        V_SQL := V_SQL||'
            ,SUM (DECODE (batch,'''||V_BATCH.BATCH||''', DECODE (TYPE, ''wm'', should_cost,0),0))
            AS wm'||X||',
            SUM (DECODE (batch,'''||V_BATCH.BATCH||''', DECODE (TYPE, ''em'', should_cost,0),0))
            AS em'||X||',
            SUM (DECODE (batch,'''||V_BATCH.BATCH||''', DECODE (TYPE, ''em'', use_num,0),0))
            AS emuse'||X;
        X:=X+1;
      END LOOP;
      
      V_SQL := 'select sys_guid() id,sysdate add_date,sysdate modify_date,'||YEAR||' year,'||SEASON||' season,aa.* from ('||V_SQL || ' FROM nine_repot GROUP BY house_name ORDER BY house_name) aa';
      --DBMS_OUTPUT.PUT_LINE(V_SQL);
      V_SQL := 'insert into ninreport '||  V_SQL;
      --DBMS_OUTPUT.PUT_LINE(V_SQL);
      EXECUTE IMMEDIATE V_SQL;
    END;
/

