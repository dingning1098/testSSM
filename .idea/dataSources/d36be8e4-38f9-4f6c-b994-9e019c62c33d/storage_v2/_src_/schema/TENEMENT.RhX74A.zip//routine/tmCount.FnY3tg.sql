create FUNCTION "tmCount" 
    RETURN NUMBER
    BEGIN
        SELECT customerID INTO cus_id
        FROM userInfo
        WHERE customerName=customer_name;
    RETURN cus_id;
END;
/

