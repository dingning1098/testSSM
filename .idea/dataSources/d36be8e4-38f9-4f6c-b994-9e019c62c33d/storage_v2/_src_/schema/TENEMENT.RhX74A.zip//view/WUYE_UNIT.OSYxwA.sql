create view WUYE_UNIT as
    select id,fc_nam from fc_card_query where fc_tree_code=3
union all
select unit_code,unit_name from tm_unit where unit_facility=3
/

