create FUNCTION          PACTFEE (FEEID       IN VARCHAR2,
                                             BILLVALUE   IN NUMBER,
                                             PAYWAY      IN VARCHAR2,
                                             PACTTYPE    IN VARCHAR2,
                                             OPERUSER    IN VARCHAR2,
                                             RENT        IN VARCHAR2,
                                             MANAGE      IN VARCHAR2,
                                             DEPOSIT     IN VARCHAR2,
                                             MARGIN      IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   DECLARE
      PACT       VARCHAR2 (500);
      BUILDING   VARCHAR2 (500);
      HOUSE      VARCHAR2 (500);
      USERID     VARCHAR2 (500);
      PHONE      VARCHAR2 (500);
      SCOST      NUMBER;
      SDATE      DATE;
      DM         NUMBER;                                                --优惠金额
      GCOST      NUMBER;
      ARR        NUMBER;
      FBD        DATE;
      FED        DATE;
      CD         DATE;
      WS         NUMBER;                                              --合同费用标志
      SEQQ       VARCHAR2 (500);
      LID        VARCHAR2 (500);
      C          NUMBER;
      D          NUMBER;

   BEGIN
      SELECT PACT_ID,
             USER_ID,
             SHOULD_COST,
             GET_COST,
             ARREARARGE,
             BGN_DATE,
             END_DATE,
             BUILDING_ID,
             HOUSE_ID,
             DISCOUNT_MONEY
        INTO PACT,
             USERID,
             SCOST,
             GCOST,
             ARR,
             FBD,
             FED,
             BUILDING,
             HOUSE,
             DM
        FROM TM_PACT_FEE
       WHERE ID = FEEID;

      SELECT SEQ_ONE.NEXTVAL INTO SEQQ FROM DUAL;



      SELECT PHONE1
        INTO PHONE
        FROM TM_RENTER
       WHERE ID = USERID;

      ARR := ARR - BILLVALUE;
      GCOST := BILLVALUE;

      WS := 0;
      D := 0;

      IF BILLVALUE > 0
      THEN
         WS := 1;
      END IF;

      IF ARR <= 0
      THEN
         D := 1;
         WS := 2;
      END IF;

      SELECT SYS_GUID () INTO LID FROM DUAL;



      INSERT INTO TM_FEES_LIST
           VALUES (PACT,
                   BUILDING,
                   HOUSE,
                   USERID,
                   PHONE,
                   SCOST,
                   SDATE,
                   GCOST,
                   ARR,
                   OPERUSER,
                   SYSDATE,
                   NULL,
                   LID,
                   OPERUSER,
                   SYSDATE,
                   OPERUSER,
                   SYSDATE,
                   PACTTYPE,
                   FEEID,
                   FBD,
                   FED,
                   PAYWAY,
                   1,
                   DM,
                   SEQQ,
                   RENT,
                   MANAGE,
                   DEPOSIT,
                   MARGIN);

      C := 0;

      IF PAYWAY = 1
      THEN
         C := 1;
         CD := SYSDATE;
      END IF;

      UPDATE TM_PACT_FEE
         SET ARREARARGE = ARR,
             GET_COST = GET_COST + BILLVALUE,
             PACT_FEE_STATUS = WS,
             CONFIRM_STATUS = C,
             CONFIRM = CD,
             RECORD_STATUS = D,
             COLLECTION_DATE = SYSDATE,
             PAY_ID = LID
       WHERE ID = FEEID;

      COMMIT;
      RES := '缴费成功';
   END;

   RETURN RES;
END;
/

