create view WUYE_REPORT as
SELECT "HOUSE_CODE",
          "HOUSE_ID",
          "ADD_DATE",
          "PM_MONEY",
          "WM_MONEY"
     FROM (SELECT house_code,
                  house_id,
                  add_date,
                  price,
                  TYPE
             FROM (SELECT *
                     FROM (  SELECT vf.TYPE,
                                    vf.type_name,
                                    tm.add_date,
                                    tm.add_userid,
                                    vf.house_id,
                                    SUM (vf.price) price,
                                    vf.house_code
                               FROM v_fee_wuye vf, tm_fees_list tm
                              WHERE pay_id IS NOT NULL AND vf.pay_id = tm.id and tm.cost_type='xq'
                           GROUP BY TYPE,
                                    vf.TYPE,
                                    vf.type_name,
                                    tm.add_date,
                                    tm.add_userid,
                                    vf.house_id,
                                    vf.house_code))) PIVOT (SUM (price) AS money
                                                     FOR TYPE
                                                     IN  ('pm' AS pm,
                                                         'wm' AS wm))
/

