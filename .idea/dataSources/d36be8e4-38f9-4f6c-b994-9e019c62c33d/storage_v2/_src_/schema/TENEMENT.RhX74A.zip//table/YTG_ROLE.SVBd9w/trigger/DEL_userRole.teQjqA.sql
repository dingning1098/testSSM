create trigger "DEL_userRole"
    before delete
    on YTG_ROLE
    for each row
begin
 delete from TestTable where TestTable.id=old:.id

end;
/

