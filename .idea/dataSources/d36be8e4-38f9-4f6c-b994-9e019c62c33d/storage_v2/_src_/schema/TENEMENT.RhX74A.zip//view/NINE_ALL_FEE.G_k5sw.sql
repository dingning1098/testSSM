create view NINE_ALL_FEE as
SELECT "ID","TYPE","ADD_DATE","MODIFY_DATE","BUILDING_ID","HOUSE_ID","ARREARARGE","BATCH","BGN_DATE","PAY_ID","RECORD_STATUS",PACT_ID
     FROM (SELECT a.*
             FROM (SELECT id,
                          'wm' TYPE,
                          add_date,modify_date,
                          building_id,
                          house_id,
                          arreararge,
                          TO_CHAR (water_batch, 'yyyy-mm') batch,
                          water_bgn_date bgn_date,
                          pay_id,
                          record_status,
													PACT_ID
                     FROM tm_water
                   UNION ALL
                   SELECT id,
                          'em',
                          add_date,modify_date,
                          building_id,
                          house_id,
                          arreararge,
                          TO_CHAR (electric_batch, 'yyyy-mm') batch,
                          electric_bgn_date bgn_date,
                          pay_id,
                          record_status,
													PACT_ID
                     FROM tm_electric
                   UNION ALL
                   SELECT id,
                          'hm',
                          add_date,modify_date,
                          building_id,
                          house_id,
                          should_cost,
                          warm_batch,
                          TO_DATE (warm_bgn_date, 'yyyy-mm-dd'),
                          pay_id,
                          record_status,
													''
                     FROM tm_warm
                   UNION ALL
                   SELECT id,
                          'ht',
                          add_date,modify_date,
                          SUBSTR (building_id, 0, 32),
                          SUBSTR (house_id, 0, 32),
                          arreararge,
                          TO_CHAR (bgn_date, 'yyyy-mm'),
                          bgn_date,
                          pay_id,
                          record_status,
													PACT_ID
                     FROM tm_pact_fee) a,
                  tm_house th,
                  tm_building tb,
                  fc_card_query fc
            WHERE     a.record_status = 0
                  AND a.pay_id IS NULL
                  AND fc.fc_guid = '9'
                  AND tb.unit_code = fc.id
                  AND th.building_id = tb.id
                  AND a.house_id = th.id)
/

