create view TM_PACT as
select ID,PACT_ID,BUILDING_ID,HOUSE_ID,USER_ID,TYPE,VALUE,FEE_ID,VAK,PAY_TYPE,SYSDATE ADD_DATE,SYSDATE MODIFY_DATE from (
 select id,pact_id,building_id,house_id,user_id,type,VALUE from (
SELECT *
  FROM tm_pact_fee
 )
 UNPIVOT (VALUE
                               FOR TYPE
                               IN (rent_fee, manage_fee, deposit_fee, pact_margin))) a,
                               (SELECT *
  FROM (SELECT fee_id, VAK, pay_TYPE
          FROM tm_pactfee_type UNPIVOT (VAK
                               FOR pay_TYPE
                               IN (rent, manage, deposit, margin)))WHERE VAK = 1) b
                               where a.type like '%'||b.pay_type||'%' and a.id = b.fee_id
/

