create FUNCTION          g_twmid (feeid in varchar)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
    DECLARE
    
    hnum number;
    hid varchar(500);
    
    
   
   
    begin
        select length(house_id) into hnum from tm_fees_list where id = feeid;
        if(hnum >0) then 
            select house_id into hid from tm_fees_list where id = feeid;
            select id into res from tm_water_meter where house_id = hid;
    
        end if;

   RETURN RES;
   end;
END;
/

