create FUNCTION          genPMF (bgndate in VARCHAR,enddate in VARCHAR, 
                                            USERID      IN VARCHAR)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   DECLARE
      CURSOR PACTHOUSES
      IS
        SELECT UNIT_FACILITY,
               BUILDING_ID,
               HOUSE_CODE,
               HOUSE_NAME,
               FLOOR_NUM,
               HOUSE_AREA,
               HOUSE_STATUS,
               HOUSE_TYPE,
               IS_TOGETHER,
               REMARK,
               HOUSE_ID,
               ADD_USERID,
               ADD_DATE,
               MODIFY_USERID,
               MODIFY_DATE,
               UNIT_NUM
          FROM (select a.unit_facility,th.BUILDING_ID,
th.HOUSE_CODE,
th.HOUSE_NAME,
th.FLOOR_NUM,
th.HOUSE_STATUS,
th.HOUSE_TYPE,
th.IS_TOGETHER,
th.REMARK,
th.ID house_id,
th.ADD_USERID,
th.ADD_DATE,
th.MODIFY_USERID,
th.MODIFY_DATE,
th.UNIT_NUM,
th.HOUSE_CATEGORY,
th.HOUSE_AREA,
th.OWNER_ID,
th.YT from tm_house th,(select tb.id,tu.unit_facility from tm_building tb,tm_unit tu where tb.unit_code = tu.unit_code and tu.unit_facility=3) a where A.ID = th.building_id);
         --搜索海港小区所有已录入房间
      mnum         NUMBER;
      BNUM         NUMBER;
      CNT          NUMBER;
      ITEMPRICE    NUMBER;
      HROW         PACTHOUSES%ROWTYPE;
      BDATE        VARCHAR(100);
      EDATE        VARCHAR(100);
      x            NUMBER;
      ndate        varchar(100);

      TYPE RH IS REF CURSOR;

      HMP_SOR      RH;
   BEGIN
      BNUM := 0;
      ndate := bgndate;
      
      --插入物业费单价
      SELECT ITEM_PRICE INTO ITEMPRICE FROM TM_PAY_ITEMS WHERE UNIT_CODE='wuye' AND TYPE_CODE='pm';
      
      --搜索是否重复生成
      select count(1) into BNUM from tm_pm where trunc(to_date(bgndate,'yyyy-mm-dd'),'MM')=trunc(to_date(last_date,'yyyy-mm-dd'),'MM');
      
      --开始和结束日期间隔月份
      
      select months_between(trunc(to_date(enddate,'yyyy-mm-dd'),'MM'),trunc(to_date(bgndate,'yyyy-mm-dd'),'MM'))+1 INTO mnum from dual;

      

      IF BNUM > 0
      THEN
         RES := '该起始日期清单已经存在！请重新选择起始日期';
      ELSE
        
        CNT := 0;
        x :=0;
        while x < mnum loop
            x:= x+1;
            BDATE := TO_CHAR(trunc(to_date(ndate,'yyyy-mm-dd'),'MM'),'yyyy-mm-dd');
            EDATE := TO_CHAR(last_day(to_date(ndate,'yyyy-mm-dd')),'yyyy-mm-dd');
            ndate := TO_CHAR(last_day(to_date(ndate,'yyyy-mm-dd'))+1,'yyyy-mm-dd');

            FOR HROW IN PACTHOUSES
            LOOP
                INSERT INTO TM_PM
                     VALUES (sys_guid(),
                             SYSDATE,
                             SYSDATE,
                             HROW.house_id,
                             BDATE,
                             EDATE,
                             EDATE,
                             HROW.HOUSE_AREA,
                             ITEMPRICE,
                             ITEMPRICE*HROW.HOUSE_AREA,
                             to_char(SYSDATE,'yyyy-mm-dd'),
                             '',
                             USERID,
                             USERID,HROW.house_code,'');
                     CNT := CNT+1;
            END LOOP;
        end loop;                
         
        RES := "CONCAT" ('清单生成成功,记录数量:', "TO_CHAR" (CNT));
        COMMIT;
        

         
      END IF;
   END;

   RETURN RES;
END;
/

