create view TM_INCOME as
SELECT a."UNIT_CODE",a."GET_COST",a."MONTH",a."YEAR"
  FROM (  SELECT unit_code,
                 SUM (get_cost) get_cost,
                 TO_CHAR (add_date, 'mm') month,
                 TO_CHAR (add_date, 'yyyy') year
            FROM (SELECT tb.unit_code, tfl.*
                    FROM tm_fees_list tfl, tm_building tb, tm_house th
                   WHERE     tfl.pact_id IS NULL
                         AND tfl.house_id = th.id(+)
                         AND th.building_id = tb.id(+)
                  UNION ALL
                  SELECT tpr.pact_belong, tfl.*
                    FROM tm_fees_list tfl, tm_pact_register tpr
                   WHERE pact_id IS NOT NULL AND tfl.pact_id = tpr.id)
        GROUP BY unit_code,
                 TO_CHAR (add_date, 'mm'),
                 TO_CHAR (add_date, 'yyyy')) a,
       fc_card_query b
 WHERE     a.unit_code = b.id
       AND b.fc_tree_code IN (2,
                              4,
                              5,
                              6)
/

