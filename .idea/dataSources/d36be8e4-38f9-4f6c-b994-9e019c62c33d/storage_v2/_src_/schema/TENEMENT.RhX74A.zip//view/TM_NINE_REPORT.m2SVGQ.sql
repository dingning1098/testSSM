create view TM_NINE_REPORT as
SELECT SYS_GUID (),
            year,
            season,
            building_id,
            house_id,
            unit_code,
            add_date,
            modify_date,
            house_name,
            NVL (wm_use_num, 0),
            NVL (wm_should_cost, 0),
            NVL (em_use_num, 0),
            NVL (em_should_cost, 0),
            NVL (wm_should_cost, 0) + NVL (em_should_cost, 0)
       FROM (SELECT *
               FROM (SELECT TYPE,
                            SEASON,
                            YEAR,
                            BUILDING_ID,
                            HOUSE_ID,
                            USE_NUM,
                            SHOULD_COST,
                            UNIT_CODE,
                            ADD_DATE,
                            MODIFY_DATE,
                            HOUSE_NAME
                       FROM tm_nine_wm) PIVOT (SUM (use_num) AS use_num,
                                              SUM (should_cost) AS should_cost
                                        FOR TYPE
                                        IN ('wm' AS wm, 'em' AS em)))
   ORDER BY year ASC, season ASC
/

