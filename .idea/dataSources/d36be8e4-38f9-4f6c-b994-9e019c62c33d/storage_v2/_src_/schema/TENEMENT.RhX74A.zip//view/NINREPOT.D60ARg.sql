create view NINREPOT as
SELECT SYS_GUID () id,
          SYSDATE add_date,
          SYSDATE modify_date,
          2019 year,
          1 season,
          aa."HOUSE_NAME",
          aa."WM1",
          aa."EM1",
          aa."EMUSE1",
          aa."WM2",
          aa."EM2",
          aa."EMUSE2",
          aa."WM3",
          aa."EM3",
          aa."EMUSE3"
     FROM (  SELECT house_name,
                    SUM (
                       DECODE (
                          batch,
                          '01-1月 -19', DECODE (TYPE, 'wm', should_cost, 0),
                          0))
                       AS wm1,
                    SUM (
                       DECODE (
                          batch,
                          '01-1月 -19', DECODE (TYPE, 'em', should_cost, 0),
                          0))
                       AS em1,
                    SUM (
                       DECODE (batch,
                               '01-1月 -19', DECODE (TYPE, 'em', use_num, 0),
                               0))
                       AS emuse1,
                    SUM (
                       DECODE (
                          batch,
                          '01-2月 -19', DECODE (TYPE, 'wm', should_cost, 0),
                          0))
                       AS wm2,
                    SUM (
                       DECODE (
                          batch,
                          '01-2月 -19', DECODE (TYPE, 'em', should_cost, 0),
                          0))
                       AS em2,
                    SUM (
                       DECODE (batch,
                               '01-2月 -19', DECODE (TYPE, 'em', use_num, 0),
                               0))
                       AS emuse2,
                    SUM (
                       DECODE (
                          batch,
                          '01-3月 -19', DECODE (TYPE, 'wm', should_cost, 0),
                          0))
                       AS wm3,
                    SUM (
                       DECODE (
                          batch,
                          '01-3月 -19', DECODE (TYPE, 'em', should_cost, 0),
                          0))
                       AS em3,
                    SUM (
                       DECODE (batch,
                               '01-3月 -19', DECODE (TYPE, 'em', use_num, 0),
                               0))
                       AS emuse3
               FROM nine_repot
           GROUP BY house_name
           ORDER BY house_name) aa
/

