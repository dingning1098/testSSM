create FUNCTION          F_payPactFee (feeid       IN VARCHAR2,
                                                  billvalue   IN NUMBER,
                                                  OPERUSER    IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   DECLARE
      pact        VARCHAR2 (500);
      building    VARCHAR2 (500);
      house       VARCHAR2 (500);
      userid      VARCHAR2 (500);
      phone       VARCHAR2 (500);
      scost       NUMBER;
      username    VARCHAR2 (500);
      gcost       NUMBER;
      arr         NUMBER;
      fbd         DATE;
      fed         DATE;
      ws          NUMBER;
      hnum        NUMBER;
      c_houseid   VARCHAR2 (500);
      

      CURSOR c_house
      IS
             SELECT REGEXP_SUBSTR (house_id,
                                   '[^;]+',
                                   1,
                                   LEVEL)
                       hid
               FROM (SELECT house_id
                       FROM tm_pact_fee
                      WHERE id = feeid)
         CONNECT BY LEVEL <= REGEXP_COUNT (house_id, '\;');
   BEGIN
      

      SELECT COUNT (1)
        INTO hnum
        FROM (    SELECT REGEXP_SUBSTR (house_id,
                                        '[^;]+',
                                        1,
                                        LEVEL)
                    FROM (SELECT house_id
                            FROM tm_pact_fee
                           WHERE id = feeid)
              CONNECT BY LEVEL <= REGEXP_COUNT (house_id, '\;'));

      SELECT pact_id,
             building_id,
             house_id,
             user_id,
             should_cost,
             get_cost,
             arreararge,
             bgn_date,
             end_date
        INTO pact,
             building,
             house,
             userid,
             scost,
             gcost,
             arr,
             fbd,
             fed
        FROM tm_pact_fee
       WHERE id = feeid;

      SELECT renter_name, phone1
        INTO username, phone
        FROM tm_renter
       WHERE id = userid;
       scost:=scost/hnum;
       
       
       



      arr := arr - billvalue;
      gcost := gcost + billvalue;
      gcost:=gcost/hnum;
      arr :=arr/hnum;
      ws := 1;

      IF arr <= 0
      THEN
         ws := 2;
      END IF;

      OPEN c_house;

      LOOP
         FETCH c_house INTO c_houseid;
         EXIT WHEN c_house%NOTFOUND;
         INSERT INTO TM_FEES_LIST
              VALUES (PACT,
                      BUILDING,
                      c_houseid,
                      username,
                      phone,
                      SCOST,
                      NULL,
                      GCOST,
                      arr,
                      OPERUSER,
                      SYSDATE,
                      NULL,
                      SYS_GUID (),
                      OPERUSER,
                      SYSDATE,
                      OPERUSER,
                      SYSDATE,
                      'ht',
                      feeid,
                      NULL,
                      NULL);

         
         end loop;

         UPDATE TM_PACT_FEE
            SET ARREARARGE = arr,
                GET_COST = GET_COST + billvalue,
                PACT_FEE_STATUS = ws,
                COLLECTION_DATE = SYSDATE
          WHERE id = feeid;

         COMMIT;
         RES := '缴费成功';
      END;

   RETURN RES;
END;
/

