create view WY_FINANCE as
SELECT "BUILDING_NAME",
          "HOUSE_NAME",
          "OWNER_NAME",
          "PAY_NUM",
          "PMFEE",
          "WATERFEE",
          "RENT_FEE",
          "MANAGE_FEE",
          "DEPOSIT_FEE",
          "PACT_MARGIN",
          "DISCOUNT_MONEY",
          "GET_COST",
          "PAY_WAY",
          "ADD_DATE",
          "UNIT_CODE",
          "BZ_DATE",
          "BZ_USER",
          SYS_GUID (),
          "FC_TREE_CODE",
          "FC_NAM",
          "ADD_DATE" modify_date
     FROM (SELECT building_name,
                  house_name,
                  owner_name,
                  pay_num,
                  pmfee,
                  waterfee,
                  rent_fee,
                  manage_fee,
                  deposit_fee,
                  pact_margin,
                  discount_money,
                  get_cost,
                  pay_way,
                  add_date,
                  unit_code,
                  bz_date,
                  bz_user
             FROM (SELECT b.owner_name,
                          b.house_name,
                          tb.building_name,
                          NVL (c.pmfee, 0) pmfee,
                          NVL (d.waterfee, 0) waterfee,
                          0 rent_fee,
                          0 manage_fee,
                          0 deposit_fee,
                          0 pact_margin,
                          bzsh.bz_date,
                          bzsh.bz_user,
                          bzsh.sh_date,
                          bzsh.sh_user,
                          tb.unit_code,
                          a.*
                     FROM (SELECT id,
                                  fee_id,
                                  house_id,
                                  get_cost,
                                  discount_money,
                                  pay_way,
                                  pay_num,
                                  add_date,
                                  modify_date
                             FROM tm_fees_list
                            WHERE pact_id IS NULL) a,
                          (SELECT tm_owner.owner_name, tm_house.*
                             FROM tm_house, tm_owner
                            WHERE tm_house.owner_id = tm_owner.id(+)) b,
                          tm_building tb,
                          (  SELECT SUM (price) pmfee, pay_id
                               FROM tm_pm
                              WHERE pay_id IS NOT NULL
                           GROUP BY pay_id) c,
                          (  SELECT SUM (should_cost) waterfee,
                                    house_id,
                                    pay_id
                               FROM tm_water
                              WHERE pay_id IS NOT NULL
                           GROUP BY house_id, pay_id) d,
                          tm_bzsh bzsh
                    WHERE     a.house_id = b.id(+)
                          AND b.building_id = tb.id(+)
                          AND a.id = c.pay_id(+)
                          AND a.id = d.pay_id(+)
                          AND a.id = bzsh.record_id(+))
           UNION ALL
           SELECT fc_nam,
                  houses_name,
                  pact_name,
                  pay_num,
                  0,
                  0,
                  rent_fee,
                  manage_fee,
                  deposit_fee,
                  pact_margin,
                  discount_money,
                  get_cost,
                  pay_way,
                  add_date,
                  pact_belong,
                  bz_date,
                  bz_user
             FROM (SELECT tfl.*,
                          CASE WHEN tfl.rent = 1 THEN a.rent_fee ELSE 0 END
                             rent_fee,
                          CASE
                             WHEN tfl.manage = 1 THEN a.manage_fee
                             ELSE 0
                          END
                             manage_fee,
                          CASE
                             WHEN tfl.deposit = 1 THEN a.deposit_fee
                             ELSE 0
                          END
                             deposit_fee,
                          CASE
                             WHEN tfl.margin = 1 THEN a.pact_margin
                             ELSE 0
                          END
                             pact_margin,
                          a.houses_name,
                          a.fc_nam,
                          a.pact_belong,
                          a.pact_name
                     FROM (SELECT tm_fees_list.*,
                                  bzsh.bz_date,
                                  bzsh.bz_user,
                                  bzsh.sh_date,
                                  bzsh.sh_user
                             FROM tm_fees_list, tm_bzsh bzsh
                            WHERE tm_fees_list.id = bzsh.record_id(+)) tfl,
                          (SELECT tm_pact_register.houses_name,
                                  ALL_FC_ID_TREE_NAM.FC_NAM,
                                  tm_pact_register.pact_belong,
                                  tm_pact_register.pact_name,
                                  TM_PACT_FEE.rent_fee,
                                  TM_PACT_FEE.manage_fee,
                                  TM_PACT_FEE.deposit_fee,
                                  TM_PACT_FEE.pact_margin,
                                  TM_PACT_FEE.id
                             FROM TM_PACT_FEE,
                                  tm_pact_register,
                                  ALL_FC_ID_TREE_NAM
                            WHERE     TM_PACT_FEE.pact_id =
                                         tm_pact_register.id(+)
                                  AND tm_pact_register.pact_belong =
                                         ALL_FC_ID_TREE_NAM.id(+)) a
                    WHERE tfl.FEE_ID = a.ID(+) AND tfl.PACT_ID IS NOT NULL))
          a,
          ALL_FC_ID_TREE_NAM b
    WHERE a.unit_code = B.ID AND b.fc_tree_code = 3
/

