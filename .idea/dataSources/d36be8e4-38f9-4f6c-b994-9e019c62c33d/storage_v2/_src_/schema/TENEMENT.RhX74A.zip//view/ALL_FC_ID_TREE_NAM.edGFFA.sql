create view ALL_FC_ID_TREE_NAM as
    SELECT id, fc_tree_code, fc_nam FROM FC_CARD_QUERY
   UNION
   SELECT unit_code AS id, TO_CHAR (unit_facility), unit_name AS fc_tree_code
     FROM tm_unit
/

