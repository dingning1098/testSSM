create FUNCTION          genwarm (UCD         IN VARCHAR,
                                             BATCH     IN VARCHAR,bgndate     in VARCHAR,enddate in VARCHAR,
                                             USERID      IN VARCHAR)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   DECLARE
      CURSOR PACTHOUSES
      IS
        SELECT 
               BUILDING_ID,
                HOUSE_CODE,
                HOUSE_NAME,
                FLOOR_NUM,
                HOUSE_STATUS,
                HOUSE_TYPE,
                IS_TOGETHER,
                REMARK,
                house_id,
                ADD_USERID,
                ADD_DATE,
                MODIFY_USERID,
                MODIFY_DATE,
                UNIT_NUM,
                HOUSE_CATEGORY,
                HOUSE_AREA,
                OWNER_ID,
                YT ,
                unit_code
          FROM (select th.BUILDING_ID,
                       th.HOUSE_CODE,
                       th.HOUSE_NAME,
                       th.FLOOR_NUM,
                       th.HOUSE_STATUS,
                       th.HOUSE_TYPE,
                       th.IS_TOGETHER,
                       th.REMARK,
                       th.ID house_id,
                       th.ADD_USERID,
                       th.ADD_DATE,
                       th.MODIFY_USERID,
                       th.MODIFY_DATE,
                       th.UNIT_NUM,
                       th.HOUSE_CATEGORY,
                       th.HOUSE_AREA,
                       th.OWNER_ID,
                       th.YT ,
                       tb.unit_code
                  from tm_house th,tm_building tb where th.building_id = tb.id  and tb.unit_code= UCD);
         --根据ucd（unit_code）检索已存在房间
      mnum         NUMBER;
      BNUM         NUMBER;
      CNT          NUMBER;
      ITEMPRICE    NUMBER;--暖气费单价
      HROW         PACTHOUSES%ROWTYPE;
      BDATE        VARCHAR(100);
      EDATE        VARCHAR(100);
      x            NUMBER;
      

      TYPE RH IS REF CURSOR;

      HMP_SOR      RH;
   BEGIN
      BNUM := 0;
      
      
      --根据ucd（unit_code）检索暖气费是否唯一
      select count(1) into mnum FROM TM_PAY_ITEMS WHERE TYPE_CODE='hm' AND UNIT_CODE= UCD;
      IF mnum > 1
      THEN
         RES := '该单元暖气费收费标准重复！';
      else if mnum=0
      then
        RES := '该单元暖气费收费标准不存在！';
      else
      
          --根据ucd（unit_code）检索暖气费
          SELECT ITEM_PRICE INTO ITEMPRICE FROM TM_PAY_ITEMS WHERE TYPE_CODE='hm' AND UNIT_CODE= UCD;
          
          --搜索是否重复生成
          select count(1) into BNUM from tm_warm where WARM_BATCH=BATCH and UNIT_CODE= UCD ;
          

          IF BNUM > 0
          THEN
             RES := '该年份已经存在！请重新选择起始日期';
          ELSE
            
            CNT := 0;
            
            FOR HROW IN PACTHOUSES
            LOOP
                INSERT INTO TM_WARM
                     VALUES (HROW.BUILDING_ID,
                             HROW.house_id,
                             sysdate,
                             ITEMPRICE,
                             HROW.HOUSE_AREA,
                             round(ITEMPRICE*HROW.HOUSE_AREA),
                             0,
                             round(ITEMPRICE*HROW.HOUSE_AREA),
                             0,
                             BATCH,
                             null,
                             sys_guid(),
                             USERID,
                             sysdate,
                             USERID,
                             sysdate,
                             0,
                             0,
                             bgndate,
                             enddate,
                             null,
                             0,
                             0,
                             null,
                             0,
                             null,
                             HROW.unit_code);
                     CNT := CNT+1;
            END LOOP;
            
                         
             
            RES := "CONCAT" ('清单生成成功,记录数量:', "TO_CHAR" (CNT));
            COMMIT;
            

             
          END IF;
      end if;
   END if;
   end;

   RETURN RES;
END;
/

