create FUNCTION            "payWaterBill" (billid IN VARCHAR2, billvalue IN NUMBER, operuser IN VARCHAR2)
RETURN VARCHAR
AS
pragma  AUTONOMOUS_TRANSACTION;
RES VARCHAR(400);
BEGIN
	-- routine body goes here, e.g.
	-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
	 DECLARE 
   building VARCHAR2(500);
   house VARCHAR2(500);
	 pact VARCHAR2(500);
	 renter VARCHAR2(500);
   phonenumber VARCHAR2(100);
	 owvalue NUMBER;
	 svalue NUMBER;
	 addDate Date;
	 nulldate Date;
	 nllstrval VARCHAR(100);
	 ws NUMBER;
	 BEGIN
   select TW.BUILDING_ID, TW.HOUSE_ID,TW.PACT_ID,TW.USER_ID,TW.ARREARARGE,TW.SHOULD_COST,TU.TELPHONE into building,house,pact,renter,owvalue,svalue,phonenumber from TM_WATER TW, TM_RENTER TU where TW.WATER_ID=billid and TW.USER_ID=TU.RENTER_ID;
	 addDate:="SYSDATE";
	 insert into TM_FEES_LIST values(pact,building,house,renter,phonenumber,svalue,nulldate,billvalue,owvalue,operuser,addDate,nllstrval,SYS_GUID(),operuser,addDate,nllstrval,nullDate,'jxstar','wm',billid);
	 
	 owvalue := owvalue-billvalue;
	 ws:=1;
	 if owvalue<=0 THEN
			ws:=2;
	 END IF;
   update TM_WATER set ARREARARGE= owvalue , GET_COST=GET_COST+billvalue, WATER_STATUS=ws where  WATER_ID=billid;
   
	 commit;
	RES:='缴费成功';
	END;
	RETURN RES;
END;


/

