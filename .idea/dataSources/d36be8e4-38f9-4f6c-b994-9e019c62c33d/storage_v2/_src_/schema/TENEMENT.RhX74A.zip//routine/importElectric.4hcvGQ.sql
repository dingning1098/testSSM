create PROCEDURE            "importElectric" (thisnum IN DOUBLE PRECISION,pooledmoney IN DOUBLE PRECISION, wid IN VARCHAR2,tenant IN VARCHAR2)
AS

	s_sql VARCHAR2(500);
  pact VARCHAR(500);
BEGIN
	-- routine body goes here, e.g.
	-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
	pact:=''''||wid||'''';
	s_sql:='update tm_electric set get_cost=0，this_num='||thisnum ||',POOLED_MONEY='||pooledmoney||' where electric_id ='||pact;
		execute immediate s_sql;
  s_sql:='update tm_electric set use_num=this_num-last_num+after_num-before_num where electric_id ='||pact;
	execute immediate s_sql;
	s_sql:='update tm_electric set should_cost=use_num*unit_price+pooled_money where electric_id ='||pact;
	execute immediate s_sql;
	s_sql:='update tm_electric set arreararge=should_cost where electric_id ='||pact;
	execute immediate s_sql;
 commit;
DBMS_OUTPUT.put_line(s_sql);
	
END;
/

