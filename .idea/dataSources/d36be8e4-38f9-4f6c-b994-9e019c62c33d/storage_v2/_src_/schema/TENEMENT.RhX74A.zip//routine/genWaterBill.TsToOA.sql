create FUNCTION            "genWaterBill" (ucd IN VARCHAR, batchid IN VARCHAR, userid IN VARCHAR, lastbatch IN VARCHAR)
RETURN VARCHAR
AS
pragma  AUTONOMOUS_TRANSACTION;
	RES VARCHAR(400);
BEGIN
	-- routine body goes here, e.g.
	-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
	DECLARE 
  cursor pacthouses is 
  --select tpr.RENTER_ID, tpr.PACT_ID,tph.building_id,tph.house_id, tph.pact_house_id from tm_pact_register tpr, tm_pact_house tph,tm_building b where b.unit_code=ucd and tpr.pact_status=1 and b.building_id=tph.building_id and tph.pact_id=tpr.pact_id;
  select tem.BUILDING_ID,tem.HOUSE_ID,tem.BEGIN_NUM,tem.WATER_METER_ID from TM_WATER_METER tem,TM_BUILDING b ,TM_HOUSE ths where b.unit_code=ucd and tem.building_id=b.building_id and tem.HOUSE_ID=ths.house_id;
  addDate Date;
	nulldate Date;
	ledate Date;
	defaultprice NUMBER;
	defaultunit varchar(100);

  price NUMBER;
  unit VARCHAR2(100);
  onid VARCHAR(100);
  pactid VARCHAR2(100);
	nllstrval VARCHAR2(100);
  renterid VARCHAR2(100);
	lastfigure NUMBER;
	this_num NUMBER;
  afternum NUMBER;
  beforenum NUMBER;
	zerono NUMBER;
  ei DECIMAL;
		  bnum DECIMAL;
	cnt DECIMAL;
	hrow pacthouses%ROWTYPE;
 
    type RH is ref cursor;    
    emp_sor RH;  
	BEGIN
			bnum:=0;
			defaultprice:=0;
		
		  select item_price,charge_unit into defaultprice,defaultunit from tm_pay_items where unit_code=ucd and TYPE_CODE='em';

				
				addDate:="SYSDATE";
				zerono:=0;
				cnt:=0;
				for hrow In pacthouses loop
								ei:=0;
								select count(*) into ei from TM_WATER  where HOUSE_ID=hrow.house_id and water_batch=batchid;
							  if ei<=0 THEN
											ei:=0;
											price :=0;
											unit :='';
                      afternum:=0;
										  beforenum:=0;
											select count(*) into ei from TM_PACT_STANDARD where pact_house_id=hrow.HOUSE_ID and STANDARD_CODE='em';
											if ei>0 THEN
												 if ei=1 THEN
														select tps.ITEM_PRICE, tps.CHARGE_UNIT,tph.pact_id ,TPR.RENTER_ID into price,unit, pactid,renterid from TM_PACT_STANDARD tps, TM_PACT_HOUSE tph, TM_PACT_REGISTER tpr where TPS.pact_house_id=hrow.HOUSE_ID and TPS.STANDARD_CODE='em' and tph.house_id=tps.pact_house_id and tpr.pact_id=tph.pact_id;
														
												  ELSE
														RES :='清单生成失败,原因:同一房间有不同的收费标准，合同房间ID='||hrow.house_id;
														rollback;
														return RES;
												  END IF;
											ELSE
												 price:=defaultprice;
												 unit:=defaultunit;
												 pactid:='';
												 renterid:='-1';
											END IF;
											
											select count(*) into ei from tm_water  where HOUSE_ID=hrow.house_id and water_batch=lastbatch;
					
											if ei>0 THEN
													if ei=1 THEN
														select this_num,WATER_END_DATE into lastfigure,ledate from tm_water where house_id=hrow.house_id and water_batch=lastbatch;
														select sum(old_end_num) - sum(BEGIN_NUM) into afternum from TM_water_METER_CHANGE where WATER_METER_ID=hrow.WATER_METER_ID and CHANGE_DATE>ledate and CHANGE_DATE<addDate;

													ELSE
														RES :='清单生成失败,原因:清单中同一批次房间有重复，房间ID='||hrow.house_id||' 批次='||lastbatch;
														rollback;
														return RES;
												  end if;
											ELSE
													lastfigure:=hrow.BEGIN_NUM;
											
											end if;
											cnt := cnt+1;

							insert into tm_water values(SYS_GUID(),userid,addDate,nllstrval,nulldate,'jxstar',pactid,hrow.building_id,hrow.house_id,renterid,lastfigure,'',beforenum,afternum,nulldate,zerono,unit,price,zerono,zerono,zerono,zerono,zerono,batchid,nllstrval,zerono,zerono,nulldate,nulldate,nulldate,zerono,zerono);
						end if;
				END Loop;
				if cnt>0 THEN
						commit;
				END if;
						RES :="CONCAT"('清单生成成功,记录数量:',"TO_CHAR"(cnt));
				
	END;

	RETURN RES;
END;


/

