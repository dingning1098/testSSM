create view TM_MOBILE_HOUSE_N as
SELECT "ID","OPEN_ID","CARD_NUM","PHONE_NUM","ADD_DATE","MODIFY_DATE","USER_ID","NAME","HOUSEID","HOUSE_NAME","C1","FLAG" FROM TM_MOBILE_BIND mb,(
			(SELECT ow.id as user_id,ow.OWNER_NAME as name,hss.id as HOUSEID,hss.HOUSE_NAME,ow.CARD_NUM as c1,'0' as flag  FROM TM_OWNER ow --业主表
			LEFT JOIN TM_HOUSE hss ON ow.ID=hss.OWNER_ID )
			UNION
			(SELECT gue.ID as user_id,gue.GUEST_NAME as name,gue.HOUSE_ID  as HOUSEID,hss.HOUSE_NAME,gue.CARD_NUM as c1,'2' as flag FROM TM_GUEST gue--住客表
			LEFT JOIN TM_HOUSE hss ON hss.ID=gue.HOUSE_ID 
			LEFT JOIN TM_BUILDING buil ON hss.BUILDING_ID=buil.ID 
			WHERE gue.GUEST_STATUS=1 and buil.UNIT_CODE NOT IN (
				SELECT ID FROM FC_CARD_QUERY WHERE FC_GUID!='1' --除了一号公寓的其他公寓住客
			))
			UNION
			(SELECT ren.id as user_id,ren.LEGAL_PERSON_NAME as name,hss.id as HOUSEID,
			hss.HOUSE_NAME,ren.LEGAL_PERSON_CARD as CARD_NUM1,'1' as flag  FROM TM_RENTER ren  --除了资产一号公寓模式的公寓及资产网点房、办公楼、环境中心外的其他租户
			LEFT JOIN TM_PACT_REGISTER pr ON ren.id=pr.RENTER_ID 
			LEFT JOIN TM_HOUSE hss ON instr(pr.RENT_HOUSES,hss.ID)>0
			WHERE pr.PACT_STATUS=1 and pr.ID not in (SELECT DISTINCT PACT_ID FROM TM_GUEST WHERE GUEST_STATUS=1) 
			AND pr.PACT_BELONG not in (SELECT ID FROM FC_CARD_QUERY WHERE FC_TREE_CODE in (4,5,6) OR FC_GUID='1'))

		) us where MB.CARD_NUM=us.c1
--此视图暂未启用
/

