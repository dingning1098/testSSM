create view TM_WUYE_OWN_REPORT as
SELECT SYS_GUID () id,
          wy.HOUSE_CODE,
          wy.HOUSE_ID,
          SYSDATE add_date,
          to_date(wy.pm_last_date,'yyyy-mm-dd'),
          to_date(wy.pm_this_date,'yyyy-mm-dd'),
          NVL (wy.pm_unituse, 0) pm_unituse,
          wy.wm_last_date,
          wy.wm_this_date,
          NVL (wy.wm_unituse, 0) wm_unituse,
          NVL (wy.PM_MONEY, 0) pm_money,
          NVL (wy.WM_MONEY, 0) wm_money,
          NVL (wy.PM_MONEY, 0) + NVL (wy.WM_MONEY, 0) SUM,
          TH.OWNER_ID,
          th.house_name,
          tm.owner_name,
          NULL modify_date
     FROM WUYE_own_REPORT wy, tm_house th, tm_owner tm
    WHERE wy.house_id = th.id AND th.owner_id = tm.id(+)
/

