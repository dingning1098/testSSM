create FUNCTION            "payRent" (pactid      IN VARCHAR2,
                                                  
                                                  operuser    IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
  
   BEGIN
      
      UPDATE TM_pact_fee
         SET ARREARARGE = 0, GET_COST = SHOULD_COST, PACT_FEE_STATUS = 2
       WHERE PACT_ID = pactid and BGN_DATE<= SYSDATE and END_DATE> SYSDATE;

      COMMIT;
      RES := '缴费成功';
   END;

   RETURN RES;
END;


/

