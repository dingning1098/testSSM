create FUNCTION          payMarket (HOUSEID    IN VARCHAR2, batch in DATE     ,                                            
                                                  OPERUSER   IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN

   DECLARE
      WID             VARCHAR2 (500);--水费ID
      EID             VARCHAR2 (500);--电费ID 
      BUILDING        VARCHAR2 (500);--楼宇ID
      HOUSE           VARCHAR2 (500);--房间ID
      water_OWVALUE   NUMBER;--水费欠缴
      water_SVALUE    NUMBER;--水费应缴
      elec_OWVALUE    NUMBER;--电费欠缴
      elec_SVALUE     NUMBER;--电费应缴
      water_fee_bgn_date   date;--水缴费起始
      water_fee_end_date   date;--水缴费结束
      elec_fee_bgn_date    date;--电缴费起始
      elec_fee_end_date    date;--电缴费结束
      fwid     varchar2(500);
      feid     varchar2(500);
      wnum   number;--水表记录条数
      enum   number;--电表记录条数
      nulstr     VARCHAR2 (500);
      nuldate    date;
      se      varchar2(500);
      
      
      
    BEGIN

        select count(1)
        into wnum 
        from tm_water
        where house_id=HOUSEID
        and water_batch=batch
        and water_status=0;
        
        select count(1)
        into enum
        from tm_electric
        where house_id=HOUSEID
        and electric_batch=batch
        and electric_status=0;
        
         --查找楼宇ID保存
        select building_id 
        into BUILDING
        from tm_house
        where id=houseid;




      --根据房间ID和批次找到相应水表电表数据
      
        if(wnum=1) then 
            fwid :=sys_guid();
            select seq_wuye.nextval into se from dual;
          
          
            select id,arreararge,should_cost,water_bgn_date,water_end_date
            into WID,water_OWVALUE,water_SVALUE,water_fee_bgn_date,water_fee_end_date
            from tm_water
            where house_id=HOUSEID
            and water_batch=batch
            and water_status=0;
            --缴费记录插入水费记录
            insert into tm_fees_list
                 values(
                 nulstr,
                 BUILDING,
                 houseid,
                 nulstr,
                 nulstr,
                 water_SVALUE,
                 nuldate,
                 water_OWVALUE,
                 water_OWVALUE,
                 OPERUSER,
                 sysdate,
                 nulstr,
                 fwid,
                 OPERUSER,
                 sysdate,
                 nulstr,
                 nuldate,
                 'wm',
                 wid,
                 water_fee_bgn_date,
                 water_fee_end_date,1,1,0,se);
                 
                 --更新水费记录已缴
                UPDATE TM_WATER
                SET ARREARARGE = 0, GET_COST = SHOULD_COST, WATER_STATUS = 2,COLLECTION_DATE=SYSDATE,pay_id=fwid
                where house_id=HOUSEID
                and water_batch=batch
                and water_status=0;
        end if;
        
        if(enum=1) then
            feid:=sys_guid();
            select seq_wuye.nextval into se from dual;
        
            select id,arreararge,should_cost,electric_bgn_date,electric_end_date
            into EID,elec_OWVALUE,elec_SVALUE,elec_fee_bgn_date,elec_fee_end_date
            from tm_electric
            where house_id=HOUSEID
            and electric_batch=batch
            and electric_status=0;
           
          --缴费记录里插记录

            insert into tm_fees_list
                 values(
                 nulstr,
                 BUILDING,
                 houseid,
                 nulstr,
                 nulstr,
                 elec_SVALUE,
                 nuldate,
                 elec_OWVALUE,
                 elec_OWVALUE,
                 OPERUSER,
                 sysdate,
                 nulstr,
                 feid,
                 OPERUSER,
                 sysdate,
                 nulstr,
                 nuldate,
                 'em',
                 eid,
                 elec_fee_bgn_date,
                 elec_fee_end_date,1,1,0,se);
            UPDATE tm_electric
            SET ARREARARGE = 0, GET_COST = SHOULD_COST, electric_STATUS = 2,COLLECTION_DATE=SYSDATE,pay_id=feid
            where house_id=HOUSEID
            and electric_batch=batch
            and electric_status=0;

        end if;

        COMMIT;
        RES := '缴费成功';
    END;

    RETURN RES;
END;
/

