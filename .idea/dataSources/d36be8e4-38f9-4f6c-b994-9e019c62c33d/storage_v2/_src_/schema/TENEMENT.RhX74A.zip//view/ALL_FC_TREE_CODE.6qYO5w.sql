create view ALL_FC_TREE_CODE as
    select id,fc_tree_code from FC_CARD_QUERY 
UNION 
select unit_code as id,to_char(unit_facility) as fc_tree_code from tm_unit
/

