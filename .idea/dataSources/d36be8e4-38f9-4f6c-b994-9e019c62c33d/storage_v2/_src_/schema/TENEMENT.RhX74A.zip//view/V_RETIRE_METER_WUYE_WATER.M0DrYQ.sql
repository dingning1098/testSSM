create view V_RETIRE_METER_WUYE_WATER as
SELECT
	WUYE.FC_NAM,
	TM_BUILDING.BUILDING_NAME,
	TM_HOUSE.HOUSE_NAME,
	ENTITY."ID",
	ENTITY."PACT_ID",
	ENTITY."HOUSE_ID",
	ENTITY."METER_NUM",
	ENTITY."GET_DATE",
	ENTITY."GET_MONEY",
	ENTITY."REMARK",
	ENTITY."ADD_USERID",
	ENTITY."ADD_DATE",
	ENTITY."MODIFY_USERID",
	ENTITY."MODIFY_DATE",
	ENTITY."METER_TYPE",
	ENTITY."METER_NO",
	ENTITY."BUILDING_ID",
	ENTITY."FEE_ID",
	NVL (
		TM_WATER.LAST_NUM,
		CD.LAST_NUM
	) AS LAST_NUM,
	TM_WATER.POOLED_MONEY,
	TM_WATER.DISCOUNT_MONEY,
	AB.UNIT_PRICE,
	NVL (AA.NUM, 0) AS NUM,
	TM_WATER.USE_NUM,
	TM_WATER.SHOULD_COST
FROM
	TM_RETIRE_METER ENTITY
LEFT JOIN TM_WATER ON ENTITY.FEE_ID = TM_WATER. ID
LEFT JOIN TM_BUILDING ON ENTITY.BUILDING_ID = TM_BUILDING. ID
LEFT JOIN TM_HOUSE ON ENTITY.HOUSE_ID = TM_HOUSE. ID
LEFT JOIN (
	SELECT
		ID,
		fc_nam
	FROM
		fc_card_query
	WHERE
		fc_tree_code = 3
	UNION ALL
		SELECT
			unit_code,
			unit_name
		FROM
			tm_unit
		WHERE
			unit_facility = 3
) WUYE ON WUYE. ID = TM_BUILDING.UNIT_CODE
LEFT JOIN V_BUILDING_HOUSE_PACT_RENTER V_BHPR ON ENTITY.HOUSE_ID = V_BHPR.HOUSE_ID
LEFT JOIN (
	SELECT
		ITEM_PRICE AS UNIT_PRICE,
		TM_HOUSE. ID
	FROM
		TM_PAY_ITEMS
	LEFT JOIN TM_HOUSE ON TM_PAY_ITEMS.TYPE_CODE = TM_HOUSE.HOUSE_CATEGORY
) AB ON ENTITY.HOUSE_ID = AB. ID --last_num
LEFT JOIN (
	SELECT
		D .HOUSE_ID,
		NVL (
			NVL (EF.THIS_NUM, C.THIS_NUM),
			D .BEGIN_NUM
		) AS LAST_NUM
	FROM
		(
			--上一个批次的this_num
			SELECT
				HOUSE_ID,
				THIS_NUM
			FROM
				TM_WATER
			WHERE
				WATER_BATCH = ADD_MONTHS (
					TO_DATE (
						(
							SELECT
								CASE
							WHEN TO_CHAR (SYSDATE, 'mm') >= 4
							AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
								TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
							WHEN TO_CHAR (SYSDATE, 'mm') >= 0
							AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
								TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
							ELSE
								TO_CHAR (
									ADD_MONTHS (SYSDATE, 12),
									'yyyy'
								) || '-03-01'
							END AS WATER_BATCH
							FROM
								dual
						),
						'yyyy-mm-dd'
					),
					- 6
				)
		) C --本批次内最后一次录入的this_num
	LEFT JOIN (
		SELECT
			E .HOUSE_ID,
			THIS_NUM,
			E . ID
		FROM
			TM_WATER E
		RIGHT JOIN (
			SELECT
				HOUSE_ID,
				MAX (WATER_BATCH) AS WATER_BATCH
			FROM
				TM_WATER
			WHERE
				THIS_NUM IS NOT NULL
			AND WATER_BATCH >= ADD_MONTHS (
				TO_DATE (
					(
						SELECT
							CASE
						WHEN TO_CHAR (SYSDATE, 'mm') >= 4
						AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
							TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
						WHEN TO_CHAR (SYSDATE, 'mm') >= 0
						AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
							TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
						ELSE
							TO_CHAR (
								ADD_MONTHS (SYSDATE, 12),
								'yyyy'
							) || '-03-01'
						END AS WATER_BATCH
						FROM
							dual
					),
					'yyyy-mm-dd'
				),
				- 5
			)
			AND WATER_BATCH < ADD_MONTHS (
				TO_DATE (
					(
						SELECT
							CASE
						WHEN TO_CHAR (SYSDATE, 'mm') >= 4
						AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
							TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
						WHEN TO_CHAR (SYSDATE, 'mm') >= 0
						AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
							TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
						ELSE
							TO_CHAR (
								ADD_MONTHS (SYSDATE, 12),
								'yyyy'
							) || '-03-01'
						END AS WATER_BATCH
						FROM
							dual
					),
					'yyyy-mm-dd'
				),
				1
			)
			GROUP BY
				HOUSE_ID
		) F ON E .HOUSE_ID = F.HOUSE_ID
		AND E .WATER_BATCH = F.WATER_BATCH
	) EF ON C.HOUSE_ID = EF.HOUSE_ID
	RIGHT JOIN TM_WATER_METER D ON C.HOUSE_ID = D .HOUSE_ID
) CD ON entity.HOUSE_ID = CD.HOUSE_ID --换表NUM
LEFT JOIN (
	SELECT
		DATES.HOUSE_ID,
		SUM (
			TM_WATER_METER_CHANGE.OLD_END_NUM
		) - SUM (
			TM_WATER_METER_CHANGE.BEGIN_NUM
		) AS NUM
	FROM
		TM_WATER_METER_CHANGE
	LEFT JOIN TM_WATER_METER ON TM_WATER_METER_CHANGE.WATER_METER_ID = TM_WATER_METER. ID --这一批次内自最后一次录入时间开始到批次结束所换表的房间
	LEFT JOIN (
		SELECT
			TM_WATER_METER.HOUSE_ID,
			NVL (
				TM_WS.BGN_DATE,
				ADD_MONTHS (
					TO_DATE (
						(
							SELECT
								CASE
							WHEN TO_CHAR (SYSDATE, 'mm') >= 4
							AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
								TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
							WHEN TO_CHAR (SYSDATE, 'mm') >= 0
							AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
								TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
							ELSE
								TO_CHAR (
									ADD_MONTHS (SYSDATE, 12),
									'yyyy'
								) || '-03-01'
							END AS WATER_BATCH
							FROM
								dual
						),
						'yyyy-mm-dd'
					) ,- 5
				)
			) AS BGN_DATE
		FROM
			TM_WATER_METER
		LEFT JOIN (
			SELECT
				TM_WATER.HOUSE_ID,
				MAX (WATER_BATCH) AS bgn_date
			FROM
				TM_WATER
			LEFT JOIN TM_RETIRE_METER ON TM_WATER. ID = TM_RETIRE_METER.FEE_ID
			LEFT JOIN V_BUILDING_HOUSE_PACT_RENTER V_BHPR ON TM_RETIRE_METER.PACT_ID = V_BHPR.PACT_ID
			WHERE
				V_BHPR.HOUSE_ID IS NULL
			AND ADD_MONTHS (WATER_BATCH, 5) >= TO_DATE (
				(
					SELECT
						CASE
					WHEN TO_CHAR (SYSDATE, 'mm') >= 4
					AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
					WHEN TO_CHAR (SYSDATE, 'mm') >= 0
					AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
					ELSE
						TO_CHAR (
							ADD_MONTHS (SYSDATE, 12),
							'yyyy'
						) || '-03-01'
					END AS WATER_BATCH
					FROM
						dual
				),
				'yyyy-mm-dd'
			)
			AND ADD_MONTHS (WATER_BATCH ,- 1) < TO_DATE (
				(
					SELECT
						CASE
					WHEN TO_CHAR (SYSDATE, 'mm') >= 4
					AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
					WHEN TO_CHAR (SYSDATE, 'mm') >= 0
					AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
					ELSE
						TO_CHAR (
							ADD_MONTHS (SYSDATE, 12),
							'yyyy'
						) || '-03-01'
					END AS WATER_BATCH
					FROM
						dual
				),
				'yyyy-mm-dd'
			)
			AND WATER_BATCH <> TO_DATE (
				(
					SELECT
						CASE
					WHEN TO_CHAR (SYSDATE, 'mm') >= 4
					AND TO_CHAR (SYSDATE, 'mm') <= 9 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-09-01'
					WHEN TO_CHAR (SYSDATE, 'mm') >= 0
					AND TO_CHAR (SYSDATE, 'mm') <= 3 THEN
						TO_CHAR (SYSDATE, 'yyyy') || '-03-01'
					ELSE
						TO_CHAR (
							ADD_MONTHS (SYSDATE, 12),
							'yyyy'
						) || '-03-01'
					END AS WATER_BATCH
					FROM
						dual
				),
				'yyyy-mm-dd'
			)
			GROUP BY
				TM_WATER.HOUSE_ID
		) TM_WS ON TM_WS.HOUSE_ID = TM_WATER_METER.HOUSE_ID
	) DATES ON TM_WATER_METER.HOUSE_ID = DATES.HOUSE_ID
	LEFT JOIN V_BUILDING_HOUSE_PACT_RENTER V_BHPR ON DATES.HOUSE_ID = V_BHPR.HOUSE_ID
	LEFT JOIN TM_RETIRE_METER ON V_BHPR.PACT_ID = TM_RETIRE_METER.PACT_ID
	AND V_BHPR.HOUSE_ID = TM_RETIRE_METER.HOUSE_ID
	WHERE
		V_BHPR.PACT_ID IS NOT NULL
	AND TM_WATER_METER_CHANGE.CHANGE_DATE >= DATES.bgn_date
	AND TM_WATER_METER_CHANGE.CHANGE_DATE < TM_RETIRE_METER.GET_DATE
	GROUP BY
		DATES.HOUSE_ID
) AA ON AA.HOUSE_ID = ENTITY.HOUSE_ID
WHERE
	entity.meter_type = 'w'
AND WUYE.FC_NAM IS NOT NULL
/

