create view TM_SEASON_WM as
SELECT b.id,b."TYPE",b."SEASON",b."YEAR",b."PACT_ID",b."HOUSE_ID",b."USE_NUM",b."SHOULD_COST",b."ADD_DATE",b."MODIFY_DATE"
     FROM TM_SEASON_WE B
    WHERE  b.pact_id IS NOT NULL
/

