create FUNCTION          payWater (HOUSEID    IN VARCHAR2,                                                  
                                                  OPERUSER   IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN

   DECLARE
      BUILDING        VARCHAR2 (500);
      HOUSE           VARCHAR2 (500);
      PACT            VARCHAR2 (500);
      WATER            VARCHAR2 (500);
      ELEC            VARCHAR2 (500);
      RENTER          VARCHAR2 (500);
      PHONENUMBER     VARCHAR2 (100);
      water_OWVALUE   NUMBER;
      water_SVALUE    NUMBER;
      elec_OWVALUE    NUMBER;
      elec_SVALUE     NUMBER;
      water_fee_bgn_date   date;
      water_fee_end_date   date;
      elec_fee_bgn_date   date;
      elec_fee_end_date   date;
      ADDDATE         DATE;
      NULLDATE        DATE;
      NLLSTRVAL       VARCHAR (100);
      WS              NUMBER;
   BEGIN
      SELECT TW.BUILDING_ID,
             TW.house_id,
             '',TW.WATER_ID,TW.ELEC_ID,
             TW.user_id,
             TW.WATER_cost,
             TW.WATER_cost,
             tw.elec_cost,
             tw.elec_cost,TW.WATER_BGN_DATE,TW.WATER_END_DATE,TW.ELECTRIC_BGN_DATE,TW.ELECTRIC_END_DATE,
             TU.TELPHONE
        INTO BUILDING,
             HOUSE,
             PACT,WATER,ELEC,
             RENTER,
             water_OWVALUE,
             water_SVALUE,
             elec_OWVALUE,
             elec_SVALUE,water_fee_bgn_date,water_fee_end_date,elec_fee_bgn_date,elec_fee_end_date,
             PHONENUMBER
        FROM V_FEE_LIST TW, TM_RENTER TU
       WHERE     TW.user_id = TU.id(+)
             AND TW.HOUSE_ID = HOUSEID;

      ADDDATE := "SYSDATE";

      INSERT INTO TM_FEES_LIST
           VALUES (PACT,
                   BUILDING,
                   HOUSE,
                   RENTER,
                   PHONENUMBER,
                   water_OWVALUE,
                   NULLDATE,
                   water_OWVALUE,
                   0,
                   OPERUSER,
                   ADDDATE,
                   NLLSTRVAL,
                   SYS_GUID (),
                   OPERUSER,
                   ADDDATE,
                   NLLSTRVAL,
                   NULLDATE,
                   
                   'wm',
                   water,
                   water_fee_bgn_date,
                   water_fee_end_date);
        INSERT INTO TM_FEES_LIST
           VALUES (PACT,
                   '',
                   HOUSE,
                   RENTER,
                   PHONENUMBER,
                   elec_OWVALUE,
                   NULLDATE,
                   elec_OWVALUE,
                   0,
                   OPERUSER,
                   ADDDATE,
                   NLLSTRVAL,
                   SYS_GUID (),
                   OPERUSER,
                   ADDDATE,
                   NLLSTRVAL,
                   NULLDATE,
                   
                   'em',
                   elec,elec_fee_bgn_date,elec_fee_end_date);
                              
                   


        if (water <>'' and water is not null)then
         UPDATE TM_WATER
          SET ARREARARGE = 0, GET_COST = SHOULD_COST, WATER_STATUS = 2,COLLECTION_DATE=SYSDATE()
         WHERE id = water;
       end if;
       if (elec <>'' and elec is not null) then
           UPDATE tm_electric
             SET ARREARARGE = 0, GET_COST = SHOULD_COST, ELECTRIC_STATUS = 2,COLLECTION_DATE=SYSDATE()
           WHERE id = elec;
       end if;

      COMMIT;
      RES := '缴费成功';
   END;

   RETURN RES;
END;
/

