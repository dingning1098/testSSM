create FUNCTION          ASSET_INCOME (YEARR IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   DECLARE
      CURSOR FEELIST
      IS
         SELECT DISTINCT (UNIT_CODE) UNIT_CODE
           FROM TM_INCOME
          WHERE YEAR = YEARR;

      INUM    NUMBER;
      FNUM    NUMBER;
      HROW    FEELIST%ROWTYPE;
      ONEID   VARCHAR2 (500);
   BEGIN
      INUM := 0;

      SELECT COUNT (1)
        INTO INUM
        FROM TM_ASSET_INCOME
       WHERE YEAR = YEARR;

      SELECT COUNT (1)
        INTO FNUM
        FROM FC_CARD_QUERY
       WHERE FC_TREE_CODE IN (2,
                              4,
                              5,
                              6);

      IF FNUM > INUM
      THEN
         DELETE FROM TM_ASSET_INCOME
               WHERE YEAR = YEARR;

         INSERT INTO TM_ASSET_INCOME
            SELECT SYS_GUID (),
                   ID,
                   YEARR,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   SYSDATE,
                   SYSDATE
              FROM FC_CARD_QUERY
             WHERE FC_TREE_CODE IN (2,
                                    4,
                                    5,
                                    6);
      END IF;

      FOR HROW IN FEELIST
      LOOP
         UPDATE TM_ASSET_INCOME
            SET (ONE,
                 TWO,
                 THREE,
                 FOUR,
                 FIVE,
                 SIX,
                 SEVEN,
                 EIGHT,
                 NINE,
                 TEN,
                 ELEVEN,
                 TWELVE) =
                   (SELECT MAX (ONE),
                           MAX (TWO),
                           MAX (THREE),
                           MAX (FOUR),
                           MAX (FIVE),
                           MAX (SIX),
                           MAX (SEVEN),
                           MAX (EIGHT),
                           MAX (NINE),
                           MAX (TEN),
                           MAX (ELEVEN),
                           MAX (TWELVE)
                      FROM (SELECT CASE
                                      WHEN MONTH = '01' THEN GET_COST
                                      ELSE 0
                                   END
                                      ONE,
                                   CASE
                                      WHEN MONTH = '02' THEN GET_COST
                                      ELSE 0
                                   END
                                      TWO,
                                   CASE
                                      WHEN MONTH = '03' THEN GET_COST
                                      ELSE 0
                                   END
                                      THREE,
                                   CASE
                                      WHEN MONTH = '04' THEN GET_COST
                                      ELSE 0
                                   END
                                      FOUR,
                                   CASE
                                      WHEN MONTH = '05' THEN GET_COST
                                      ELSE 0
                                   END
                                      FIVE,
                                   CASE
                                      WHEN MONTH = '06' THEN GET_COST
                                      ELSE 0
                                   END
                                      SIX,
                                   CASE
                                      WHEN MONTH = '07' THEN GET_COST
                                      ELSE 0
                                   END
                                      SEVEN,
                                   CASE
                                      WHEN MONTH = '08' THEN GET_COST
                                      ELSE 0
                                   END
                                      EIGHT,
                                   CASE
                                      WHEN MONTH = '09' THEN GET_COST
                                      ELSE 0
                                   END
                                      NINE,
                                   CASE
                                      WHEN MONTH = '10' THEN GET_COST
                                      ELSE 0
                                   END
                                      TEN,
                                   CASE
                                      WHEN MONTH = '11' THEN GET_COST
                                      ELSE 0
                                   END
                                      ELEVEN,
                                   CASE
                                      WHEN MONTH = '12' THEN GET_COST
                                      ELSE 0
                                   END
                                      TWELVE
                              FROM TM_INCOME
                             WHERE     YEAR = YEARR
                                   AND UNIT_CODE = HROW.UNIT_CODE))
          WHERE FC_ID = HROW.UNIT_CODE and year = yearr;
      END LOOP;

      SELECT ID
        INTO ONEID
        FROM FC_CARD_QUERY
       WHERE FC_GUID = '1';

      UPDATE TM_ASSET_INCOME
         SET (ONE,
              TWO,
              THREE,
              FOUR,
              FIVE,
              SIX,
              SEVEN,
              EIGHT,
              NINE,
              TEN,
              ELEVEN,
              TWELVE) =
                (SELECT MAX (ONE),
                        MAX (TWO),
                        MAX (THREE),
                        MAX (FOUR),
                        MAX (FIVE),
                        MAX (SIX),
                        MAX (SEVEN),
                        MAX (EIGHT),
                        MAX (NINE),
                        MAX (TEN),
                        MAX (ELEVEN),
                        MAX (TWELVE)
                   FROM (SELECT CASE
                                   WHEN MONTHh = '01' THEN GET_COST
                                   ELSE 0
                                END
                                   ONE,
                                CASE
                                   WHEN MONTHh = '02' THEN GET_COST
                                   ELSE 0
                                END
                                   TWO,
                                CASE
                                   WHEN MONTHh = '03' THEN GET_COST
                                   ELSE 0
                                END
                                   THREE,
                                CASE
                                   WHEN MONTHh = '04' THEN GET_COST
                                   ELSE 0
                                END
                                   FOUR,
                                CASE
                                   WHEN MONTHh = '05' THEN GET_COST
                                   ELSE 0
                                END
                                   FIVE,
                                CASE
                                   WHEN MONTHh = '06' THEN GET_COST
                                   ELSE 0
                                END
                                   SIX,
                                CASE
                                   WHEN MONTHh = '07' THEN GET_COST
                                   ELSE 0
                                END
                                   SEVEN,
                                CASE
                                   WHEN MONTHh = '08' THEN GET_COST
                                   ELSE 0
                                END
                                   EIGHT,
                                CASE
                                   WHEN MONTHh = '09' THEN GET_COST
                                   ELSE 0
                                END
                                   NINE,
                                CASE
                                   WHEN MONTHh = '10' THEN GET_COST
                                   ELSE 0
                                END
                                   TEN,
                                CASE
                                   WHEN MONTHh = '11' THEN GET_COST
                                   ELSE 0
                                END
                                   ELEVEN,
                                CASE
                                   WHEN MONTHh = '12' THEN GET_COST
                                   ELSE 0
                                END
                                   TWELVE
                           FROM (  SELECT SUM (MONEY) GET_COST,
                                          TO_CHAR (ADD_DATE, 'mm') MONTHh,
                                          TO_CHAR (ADD_DATE, 'yyyy') YEARs
                                     FROM TM_FEES_LIST_PERSON
                                 GROUP BY TO_CHAR (ADD_DATE, 'mm'),
                                          TO_CHAR (ADD_DATE, 'yyyy'))
                          WHERE YEARs = YEARR))
       WHERE FC_ID = ONEID and year = yearr;

      UPDATE tm_asset_income
         SET SUM =
                  one
                + two
                + three
                + four
                + five
                + six
                + seven
                + eight
                + eight
                + ten
                + eleven
                + twelve;

      COMMIT;
      res := '成功！';
      RETURN RES;
   END;
END;
/

