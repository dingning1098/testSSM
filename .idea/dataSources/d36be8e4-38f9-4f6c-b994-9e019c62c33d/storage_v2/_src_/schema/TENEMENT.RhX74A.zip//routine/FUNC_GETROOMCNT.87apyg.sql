create FUNCTION          FUNC_GetRoomCnt(fcGuid varchar2,fcFloor varchar2,roomyear varchar2) RETURN varchar2 IS
tmpVar varchar2(10);
/******************************************************************************
   NAME:       FUNC_GetRoomCnt
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2018/12/26   DWF       1. Created this function.

******************************************************************************/
BEGIN

    select nvl(count(1),0) into tmpVar from X_FC_CARD_ROOM where fc_guid = fcGuid and floor = fcFloor and year = roomyear;

   RETURN tmpVar;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END FUNC_GetRoomCnt;
/

