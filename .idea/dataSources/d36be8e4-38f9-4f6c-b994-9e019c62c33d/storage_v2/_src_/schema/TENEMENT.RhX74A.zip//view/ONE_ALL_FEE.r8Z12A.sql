create view ONE_ALL_FEE as
    SELECT ID,
       FEE_TYPE,
       BATCH,
       FEE_ID,
       USE,
       MONEY,
       ADD_DATE,
       MODIFY_DATE,
       PAY_ID,
       BED_ID,
       PAY_STATUS,
       PRICE,
       BGN_DATE,
       END_DATE,
			 HOUSE_ID,
			 '' as PACT_ID
  FROM tm_fee_person
  WHERE PAY_ID IS NULL AND PAY_STATUS=0
  union all

SELECT ID ,'ht',to_char(bgn_date,'yyyy-mm'),id,rent_fee,arreararge,add_date,modify_date,pay_id,bed_id,record_status,0,bgn_date,end_date,hosue,PACT_ID from


(
SELECT tpf.*, SUBSTR (tpr.rent_beds, 0, 32) BED_ID, SUBSTR (tpf.HOUSE_ID, 0, 32) hosue
  FROM tm_pact_fee tpf, tm_pact_register tpr, fc_card_query fc
 WHERE     fc.fc_guid = '1'
       AND tpr.pact_belong = fc.id
       AND tpf.pact_id = tpr.id
       AND TPR.RENT_BEDS IS NOT NULL
       AND TPF.PAY_ID IS NULL)
/

