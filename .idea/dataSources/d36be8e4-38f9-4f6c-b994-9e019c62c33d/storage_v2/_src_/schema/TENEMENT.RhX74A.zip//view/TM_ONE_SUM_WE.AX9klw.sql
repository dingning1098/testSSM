create view TM_ONE_SUM_WE as
SELECT bed_id, nvl(SUM (money),0)
       FROM tm_fee_person
      WHERE fee_type <> 'hm' AND pay_status = 0
   GROUP BY bed_id
/

