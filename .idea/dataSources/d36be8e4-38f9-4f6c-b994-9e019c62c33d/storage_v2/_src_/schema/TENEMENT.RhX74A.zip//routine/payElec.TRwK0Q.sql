create FUNCTION            "payElec" (pactid      IN VARCHAR2,
                                                  
                                                  operuser    IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   DECLARE
      building      VARCHAR2 (500);
      house         VARCHAR2 (500);
      pact          VARCHAR2 (500);
      renter        VARCHAR2 (500);
      phonenumber   VARCHAR2 (100);
      owvalue       NUMBER;
      svalue        NUMBER;
      addDate       DATE;
      nulldate      DATE;
      nllstrval     VARCHAR (100);
      ws            NUMBER;
   BEGIN
      SELECT TW.BUILDING_ID,
             TW.rent_houses,
             TW.PACT_ID,
             TW.renter_id,
             TW.elec,
             TW.elec,
             TU.TELPHONE
        INTO building,
             house,
             pact,
             renter,
             owvalue,
             svalue,
             phonenumber
        FROM v_fee_list TW, TM_RENTER TU
       WHERE TW.renter_id = TU.RENTER_ID(+) AND tw.PACT_ID = pactid;

      addDate := "SYSDATE";

      INSERT INTO TM_FEES_LIST
           VALUES (pact,
                   '',
                   house,
                   renter,
                   phonenumber,
                   svalue,
                   nulldate,
                   owvalue,
                   owvalue,
                   operuser,
                   addDate,
                   nllstrval,
                   SYS_GUID (),
                   operuser,
                   addDate,
                   nllstrval,
                   nullDate,
                   'jxstar',
                   'em',
                   '');


      UPDATE TM_electric
         SET ARREARARGE = 0, GET_COST = SHOULD_COST, electric_STATUS = 2
       WHERE PACT_ID = pactid;

      COMMIT;
      RES := '缴费成功';
   END;

   RETURN RES;
END;


/

