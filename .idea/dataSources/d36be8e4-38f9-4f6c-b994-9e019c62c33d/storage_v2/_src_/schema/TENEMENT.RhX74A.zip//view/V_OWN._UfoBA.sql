create view V_OWN as
SELECT A.RENTER_ID,
          A.BUILDING_ID,
          A.PACT_CODE,
          A.PACT_NAME,
          A.REGISTER_DATE,
          A.BGN_DATE,
          A.END_DATE,
          A.RENT_HOUSES,
          A.RENT_BEDS,
          A.WARN_DAYS,
          A.REMARK,
          A.ID,
          A.ADD_USERID,
          A.ADD_DATE,
          A.MODIFY_USERID,
          A.MODIFY_DATE,
          A.PACT_STATUS,
          A.PACT_BELONG,
          A.HOUSES_NAME,
          A.BEDS_NAME,
          A.RENTER_NAME,
          A.PACT_USE_STATUS,
          A.PACT_COST_PERIOD,
          A.FEE_DAYS,
          A.CHARGE_DATE,
          A.LATE_FEES,
          NVL (B.GET_COST, 0) GET_COST,
          NVL (C.COST_NUM, 0) COST_NUM,
          NVL (D.TOTAL_NUM, 0) TOTAL_NUM,
          CASE
             WHEN (NVL (D.TOTAL_NUM, 0) - NVL (B.GET_COST, 0)) <
                     NVL (C.COST_NUM, 0)
             THEN
                NVL (D.TOTAL_NUM, 0) - NVL (B.GET_COST, 0)
             ELSE
                NVL (C.COST_NUM, 0)
          END
             OWN_NUM,
          CASE
             WHEN (  NVL (C.COST_NUM, 0)
                   + NVL (B.GET_COST, 0)
                   - NVL (D.TOTAL_NUM, 0)) < 0
             THEN
                0
             ELSE
                  NVL (C.COST_NUM, 0)
                + NVL (B.GET_COST, 0)
                - NVL (D.TOTAL_NUM, 0)
          END
             GET_PACT,'',''
     FROM (SELECT RENTER_ID,
                  BUILDING_ID,
                  PACT_CODE,
                  PACT_NAME,
                  REGISTER_DATE,
                  BGN_DATE,
                  END_DATE,
                  RENT_HOUSES,
                  RENT_BEDS,
                  WARN_DAYS,
                  REMARK,
                  ID,
                  ADD_USERID,
                  ADD_DATE,
                  MODIFY_USERID,
                  MODIFY_DATE,
                  PACT_STATUS,
                  PACT_BELONG,
                  HOUSES_NAME,
                  BEDS_NAME,
                  RENTER_NAME,
                  PACT_USE_STATUS,
                  PACT_COST_PERIOD,
                  FEE_DAYS,
                  CHARGE_DATE,
                  LATE_FEES
             FROM TM_PACT_REGISTER
            WHERE    PACT_USE_STATUS = 3
                  OR PACT_USE_STATUS = 4
                  OR PACT_USE_STATUS = 8) A,
          (  SELECT PACT_ID, SUM (GET_COST) GET_COST
               FROM TM_PACT_FEE
           GROUP BY PACT_ID) B,
          (SELECT COST_NUM, PACT_ID
             FROM TM_PACT_COST
            WHERE COST_NAME = 1) C,
          (  SELECT SUM (COST_NUM) TOTAL_NUM, PACT_ID
               FROM TM_PACT_COST
           GROUP BY PACT_ID) D
    WHERE A.ID = B.PACT_ID(+) AND A.ID = C.PACT_ID AND A.ID = D.PACT_ID(+)
/

