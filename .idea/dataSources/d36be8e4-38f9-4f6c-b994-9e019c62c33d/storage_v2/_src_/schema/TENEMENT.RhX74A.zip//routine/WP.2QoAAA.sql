create FUNCTION          WP (PACTID   IN VARCHAR,
                                                   BATCHS   IN VARCHAR,
                                                   OPER     IN VARCHAR)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN

   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   
   DECLARE
      --搜索指定合同所有床位
      CURSOR PERSON
      IS
             SELECT REGEXP_SUBSTR (RENT_BEDS,
                                   '[^;]+',
                                   1,
                                   LEVEL)
                       BED
               FROM (SELECT *
                       FROM TM_PACT_REGISTER
                      WHERE ID = PACTID)
         CONNECT BY LEVEL <= REGEXP_COUNT (RENT_BEDS, '[^;]+');


      GID      VARCHAR2 (500);
      
      BID      VARCHAR2 (500);
      HID      VARCHAR2 (500);
      PROW     PERSON%ROWTYPE;
     
      WMONEY   NUMBER;
      UC       VARCHAR2 (500);
      CNT      NUMBER;
   BEGIN
   
      CNT := 0;
      



      --插入house_id
      SELECT SUBSTR (RENT_HOUSES, 1, INSTR (BUILDING_ID, ';') - 1),
             SUBSTR (BUILDING_ID, 1, INSTR (BUILDING_ID, ';') - 1),
             PACT_BELONG
        INTO HID, BID, UC
        FROM TM_PACT_REGISTER
       WHERE ID = PACTID;



      --插入床位暖气费
      SELECT SHOULD_COST / 3
        INTO WMONEY
        FROM TM_WARM
       WHERE HOUSE_ID = HID;
       

      FOR PROW IN PERSON
      
      LOOP
         SELECT ID
           INTO GID
           FROM TM_GUEST
          WHERE GUEST_STATUS = 1 AND BED_ID = PROW.BED;


         INSERT INTO TM_FEE_PERSON
              VALUES (SYS_GUID (),
                      GID,
                      'hm',
                      BATCHS,
                      HID,
                      BID,
                      NULL,
                      NULL,
                      WMONEY,
                      OPER,
                      SYSDATE,
                      NULL,
                      NULL,
                      NULL,
                      UC,
                      PROW.BED);

         CNT := CNT + 1;
      END LOOP;


      RES := "CONCAT" ('清单生成成功,记录数量:', "TO_CHAR" (CNT));
      COMMIT;
   END;

   RETURN RES;
END;
/

