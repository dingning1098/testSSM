create view NINE_REPOT as
SELECT th.house_name,
            tb.unit_code,
            aa."TYPE",
            aa."ADD_DATE",
            aa."MODIFY_DATE",
            aa."BUILDING_ID",
            aa."HOUSE_ID",
            aa."USE_NUM",
            aa."SHOULD_COST",
            aa."BATCH"
       FROM (SELECT 'wm' TYPE,
                    add_date,
                    modify_date,
                    building_id,
                    house_id,
                    use_num,
                    should_cost,
                    water_batch batch
               FROM tm_water
             UNION
             SELECT 'em',
                    add_date,
                    modify_date,
                    building_id,
                    house_id,
                    use_num,
                    should_cost,
                    electric_batch
               FROM tm_electric) aa,
            tm_house th,
            tm_building tb,
            fc_card_query fc
      WHERE     aa.building_id = tb.id
            AND AA.HOUSE_ID = th.id(+)
            AND fc.fc_guid = '9'
            AND fc.id = tb.unit_code
   ORDER BY house_name ASC, batch DESC, TYPE ASC
/

