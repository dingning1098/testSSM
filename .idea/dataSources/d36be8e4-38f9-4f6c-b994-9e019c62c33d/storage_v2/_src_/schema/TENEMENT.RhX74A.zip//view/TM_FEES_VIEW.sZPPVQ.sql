create view TM_FEES_VIEW as
SELECT b.building_name,
          b.UNIT_CODE,
          c.house_code,
          c.HOUSE_NAME,
          d.RENTER_NAME,
          e.type_name,
          a.PACT_ID,
          a.discount_money,
          a.BUILDING_ID,
          a.HOUSE_ID,
          a.USER_ID,
          a.USER_PHONE,
          a.SHOULD_COST,
          a.SHOULD_DATE,
          a.GET_COST,
          a.ARREARARGE,
          a.CALLABLE_USER,
          a.CALLABLE_DATE,
          a.REMARK,
          a.ID,
          a.ADD_USERID,
          a.ADD_DATE,
          a.MODIFY_USERID,
          a.MODIFY_DATE,
          a.COST_TYPE,
          a.FEE_ID,
          a.FEE_BGN_DATE,
          a.FEE_END_DATE,
          a.PAY_WAY,
          a.PAY_NUM,
          A.SEQ,c.owner_name
     FROM TM_FEES_LIST a,
          TM_BUILDING b,
          (select tm_house.*,tm_owner.owner_name from tm_house,tm_owner where tm_house.owner_id = tm_owner.id(+)) c,
          TM_RENTER d,
          TM_PAY_TYPE e,tm_owner f
    WHERE     a.BUILDING_ID = b.id(+)
          AND a.HOUSE_ID = c.id(+)
          AND a.USER_ID = d.id(+)
          AND a.COST_TYPE = e.TYPE_CODE(+)
/

