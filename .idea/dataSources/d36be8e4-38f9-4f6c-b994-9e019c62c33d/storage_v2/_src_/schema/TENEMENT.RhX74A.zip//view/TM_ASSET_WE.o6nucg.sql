create view TM_ASSET_WE as
SELECT HOUSE_NAME,
            TYPE,
            PACT_ID,
            BUILDING_ID,
            HOUSE_ID,
            USER_ID,
            MIN (LAST_NUM) last_num,
            MAX (THIS_NUM) this_num,
            SUM (USE_NUM) use_num,
            SUM (POOLED_MONEY) POOLED_MONEY,
            SUM (ARREARARGE) ARREARARGE,
            MIN (BGN_DATE) BGN_DATE,
            MAX (END_DATE) END_DATE,
            SUM (SERVICE_FEE) SERVICE_FEE,
            SYS_GUID () id,
            NULL add_date,
            NULL modify_date
       FROM ASSET_WE
   GROUP BY HOUSE_NAME,
            TYPE,
            PACT_ID,
            BUILDING_ID,
            HOUSE_ID,
            USER_ID
/

