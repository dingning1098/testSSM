create view TM_ONE_REPORT as
SELECT ID,GUEST_ID,BATCH,HOUSE_ID,BUILDING_ID,UNIT_CODE,BED_ID,WM_USE,WM_MONEY,EM_USE,EM_MONEY,RENT,WM_MONEY+EM_MONEY+RENT SUM,ADD_DATE,MODIFY_DATE FROM (
SELECT SYS_GUID () ID,
       guest_id,
       batch,
       house_id,
       building_id,
       unit_code,
       bed_id,
       NVL (wm_use, 0) WM_USE,
       NVL (wm_money, 0) WM_MONEY,
       NVL (em_use, 0) em_use,
       NVL (em_money, 0) em_money,
       
       SYSDATE add_date,
       SYSDATE modify_date,
       (SELECT nvl(SUM (tm_pact_fee.arreararge),0)
          FROM tm_pact_fee, tm_pact_register
         WHERE     SUBSTR (tm_pact_register.rent_beds, 0, 32) = bed_id
               AND tm_pact_fee.pact_id = tm_pact_register.id and tm_pact_fee.record_status=0 and tm_pact_fee.pay_id is null)
          rent
  FROM (SELECT *
          FROM (SELECT GUEST_ID,
                       FEE_TYPE,
                       BATCH,
                       HOUSE_ID,
                       BUILDING_ID,
                       USE,
                       MONEY,
                       UNIT_CODE,
                       BED_ID
                  FROM tm_fee_person
                 WHERE pay_status = 0 AND fee_type <> 'hm') PIVOT (SUM (use) AS use,
                                                                  SUM (money) AS money
                                                            FOR fee_type
                                                            IN  ('wm' AS wm,
                                                                'em' AS em))))
/

