create FUNCTION          PAYWARM (HOUSEID    IN VARCHAR2,
                                              OPERUSER   IN VARCHAR2)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   DECLARE
      BUILDING   VARCHAR2 (500);
      PACT       VARCHAR2 (500);
      RENTER     VARCHAR2 (500);
      PHONE      VARCHAR2 (100);
      SCOST      NUMBER;
      SDATE      DATE;
      TDATE      DATE;
      GCOST      NUMBER;
      AR         NUMBER;
      WID        VARCHAR2 (500);
   BEGIN
      SELECT A.PACT_ID,
             A.BUILDING_ID,
             A.USER_ID,
             B.TELPHONE,
             A.SHOULD_COST,
             A.GET_COST,
             A.ARREARARGE,
             A.ID
        INTO PACT,
             BUILDING,
             RENTER,
             PHONE,
             SCOST,
             GCOST,
             AR,
             WID
        FROM TM_WARM A, TM_RENTER B
       WHERE A.USER_ID = B.ID(+) AND A.HOUSE_ID = HOUSEID;

      TDATE := SYSDATE;

      INSERT INTO TM_FEES_LIST
           VALUES (PACT,
                   BUILDING,
                   HOUSEID,
                   RENTER,
                   PHONE,
                   SCOST,
                   NULL,
                   GCOST,
                   AR,
                   OPERUSER,
                   TDATE,
                   null,
                   SYS_GUID (),
                   OPERUSER,
                   TDATE,
                   OPERUSER,
                   TDATE,
                   'hm',
                   WID,null,null);

      UPDATE TM_WARM
         SET ARREARARGE = 0, GET_COST = SHOULD_COST, WARM_STATUS = 2,COLLECTION_DATE=SYSDATE()
       WHERE HOUSE_ID = HOUSEID;

      COMMIT;
      RES := '缴费成功';
   END;

   RETURN RES;
END;
/

