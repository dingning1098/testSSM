create FUNCTION          upwater (houseid       IN VARCHAR2,
                                                payid in varchar2,
                                                  yearr   IN NUMBER,
                                                  season    IN VARCHAR2
                                                  )
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   
   BEGIN
      

      

         UPDATE tm_water
            SET record_status=1,
                collection_date=sysdate,
                GET_COST = SHOULD_COST,
                pay_id=payid
          WHERE house_id = houseid and to_char(ADD_MONTHS (WATER_BATCH, 1),'yyyy')=yearr and to_char(ADD_MONTHS (WATER_BATCH, 1),'Q')=season;

         COMMIT;
         RES := '1';
      END;

   RETURN RES;
END;
/

