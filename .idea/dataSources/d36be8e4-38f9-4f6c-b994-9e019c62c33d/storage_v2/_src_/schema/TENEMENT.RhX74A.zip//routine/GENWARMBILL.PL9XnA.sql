create FUNCTION          genWarmBill (UCD         IN VARCHAR,
                                                     BATCHID     IN VARCHAR,
                                                     USERID      IN VARCHAR)
   RETURN VARCHAR
AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   RES   VARCHAR (400);
BEGIN
   -- routine body goes here, e.g.
   -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
   DECLARE
      CURSOR PACTHOUSES
      IS
         SELECT A.PACT_ID,
       B.ID HOUSE_ID,
       C.ID BUILDING_ID,
       D.ID USER_ID,
       B.HOUSE_AREA,
       C.UNIT_CODE
       
  FROM TM_PACT_HOUSE A,
       TM_HOUSE B,
       TM_BUILDING C,
       TM_RENTER D,
       TM_PACT_REGISTER E
 WHERE     A.BUILDING_ID = C.ID(+)
       AND A.HOUSE_ID = B.ID
       AND B.HOUSE_STATUS = 1
       AND A.PACT_ID = E.ID
       AND E.RENTER_ID = D.ID
       AND C.UNIT_CODE= UCD;

      ADDDATE      DATE;
      NULLDATE     DATE;
      PRICE        DECIMAL;
      UNIT         VARCHAR (100);
      
      NLLSTRVAL    VARCHAR (100);
      
      
      ZERONO       DECIMAL;
      EI           DECIMAL;
      BNUM         DECIMAL;
      CNT          DECIMAL;
      ITEMPRICE   DECIMAL;
      HROW         PACTHOUSES%ROWTYPE;

      TYPE RH IS REF CURSOR;

      HMP_SOR      RH;
   BEGIN
      BNUM := 0;

      SELECT COUNT (*)
        INTO BNUM
        FROM TM_WARM TW, TM_BUILDING TB
       WHERE     TB.UNIT_CODE = UCD
             AND TW.WARM_BATCH = BATCHID
             AND TW.BUILDING_ID = TB.ID;

      IF BNUM > 0
      THEN
         RES := '该批次清单已经存在！！！';
      ELSE
         ADDDATE := "SYSDATE";
         ZERONO := 0;
         CNT := 0;

         FOR HROW IN PACTHOUSES
         LOOP
            EI := 0;
            PRICE := 0;
            UNIT := 'a';

            SELECT COUNT (*)
              INTO EI
              FROM TM_PACT_STANDARD
             WHERE     PACT_HOUSE_ID = HROW.HOUSE_ID
                   AND STANDARD_CODE = 'hm';

            IF EI > 0
            THEN
               IF EI = 1
               THEN
                  SELECT ITEM_PRICE,ITEM_PRICE * HROW.HOUSE_AREA, CHARGE_UNIT
                    INTO ITEMPRICE,PRICE, UNIT
                    FROM TM_PACT_STANDARD
                   WHERE     PACT_HOUSE_ID = HROW.HOUSE_ID
                         AND STANDARD_CODE = 'hm';
                         CNT := CNT + 1;


                    INSERT INTO TM_WARM
                         VALUES (HROW.PACT_ID,
                                 HROW.BUILDING_ID,
                                 HROW.HOUSE_ID,
                                 HROW.USER_ID,
                                 ADDDATE,
                                 UNIT,
                                 ITEMPRICE,
                                 PRICE,
                                 ZERONO,
                                 PRICE,
                                 ZERONO,
                                 BATCHID,
                                 NLLSTRVAL,
                                 SYS_GUID(),
                                 USERID,
                                 ADDDATE,
                                 NLLSTRVAL,
                                 NULLDATE,
                                 ZERONO,
                                 0,
                                 NULLDATE,
                                 NULLDATE,
                                 NULLDATE,
                                 0,
                                 0,NULLDATE,0);
               ELSE
                  RES :=
                        '清单生成失败,原因:同一房间有不同的收费标准，合同房间ID='
                     || HROW.HOUSE_ID;
                  ROLLBACK;
                  RETURN RES;
               END IF;
            END IF;

            

            
         END LOOP;

         IF CNT > 0
         THEN
            RES := "CONCAT" ('清单生成成功,记录数量:', "TO_CHAR" (CNT));
            COMMIT;
         ELSE 
           RES :='生成清单不成功！房间未设置暖气收费标准！';
         END IF;

         
      END IF;
   END;

   RETURN RES;
END;
/

