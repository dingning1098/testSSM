create FUNCTION            "payPactFee" (billid IN VARCHAR2, billvalue IN NUMBER)
RETURN VARCHAR
AS
pragma  AUTONOMOUS_TRANSACTION;
RES VARCHAR(400);
BEGIN
    -- routine body goes here, e.g.
    -- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
     DECLARE 
   
     owvalue NUMBER;
     
     ws NUMBER;
     BEGIN
   
     
     owvalue := owvalue-billvalue;
     ws:=1;
     if owvalue<=0 THEN
            ws:=2;
     END IF;
   update TM_PACT_FEE set ARREARARGE= owvalue , GET_COST=GET_COST+billvalue, PACT_FEE_STATUS=ws where  id=billid;
   
     commit;
    RES:='缴费成功';
    END;
    RETURN RES;
END;

/

