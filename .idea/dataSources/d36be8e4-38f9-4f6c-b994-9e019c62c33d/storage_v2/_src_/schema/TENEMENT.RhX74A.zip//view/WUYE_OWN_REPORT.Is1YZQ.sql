create view WUYE_OWN_REPORT as
SELECT "HOUSE_CODE",
          "HOUSE_ID",
          "PM_MONEY",
          "PM_LAST_DATE",
          "PM_THIS_DATE",
          "PM_UNITUSE",
          "WM_MONEY",
          "WM_LAST_DATE",
          "WM_THIS_DATE",
          "WM_UNITUSE"
     FROM (SELECT house_code,
                  house_id,
                  price,
                  TYPE,
                  unit_use,
                  last_date,
                  this_date
             FROM (SELECT *
                     FROM (  SELECT vf.TYPE,
                                    vf.type_name,
                                    MIN (vf.last_date) last_date,
                                    MAX (vf.this_date) this_date,
                                    SUM (vf.unit) unit_use,
                                    vf.house_id,
                                    SUM (vf.price) price,
                                    vf.house_code
                               FROM v_fee_wuye vf
                              WHERE pay_id IS NULL
                           GROUP BY TYPE,
                                    vf.TYPE,
                                    vf.type_name,
                                    vf.house_id,
                                    vf.house_code))) PIVOT (SUM (price) AS money,
                                                           MIN (last_date) AS last_date,
                                                           MAX (this_date) this_date,
                                                           SUM (unit_use) AS unituse
                                                     FOR TYPE
                                                     IN  ('pm' AS pm,
                                                         'wm' AS wm))
/

