create view V_WARM as
SELECT SYS_GUID (),
            renter_id,
            unit_code,
            SUM (get_cost),
            warm_batch,
            SUM (house_area),
            item_price
       FROM (SELECT A.item_price,
                    A.GET_COST,
                    a.warm_batch,
                    d.renter_id,
                    C.HOUSE_AREA,
                    B.UNIT_CODE
               FROM tm_warm a,
                    tm_building b,
                    tm_house c,V_BUILDING_HOUSE_PACT_RENTER d
              WHERE     a.house_id = C.ID
                    AND a.building_id = b.id and c.id = d.house_id
                    )
   GROUP BY renter_id,
            unit_code,
            warm_batch,
            item_price
/

